/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "screenshot-wide.png",
    "revision": "f123d282482a8ef4aa5d1444bd54cbcd"
  }, {
    "url": "screenshot-narrow.png",
    "revision": "1d485cbaabccee17ca6a642d7248c542"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "99a242fe55e0bd9ba3c5e44f65f2eefc"
  }, {
    "url": "pwa-512x512.png",
    "revision": "99a242fe55e0bd9ba3c5e44f65f2eefc"
  }, {
    "url": "pwa-192x192.png",
    "revision": "50676b368226cd62343ab000e07d6700"
  }, {
    "url": "index.html",
    "revision": "5b2fb825b358c7d5c6e5e9cacc5ade7a"
  }, {
    "url": "icon.svg",
    "revision": "dcc5c30c5338af391879c1b9901c00ae"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "c005222080c2ebf8dc21ec1d7dfb0e0d"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/index-TC04MQxK.css",
    "revision": null
  }, {
    "url": "assets/index-DYmxE02S.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "c005222080c2ebf8dc21ec1d7dfb0e0d"
  }, {
    "url": "icon.svg",
    "revision": "dcc5c30c5338af391879c1b9901c00ae"
  }, {
    "url": "pwa-192x192.png",
    "revision": "50676b368226cd62343ab000e07d6700"
  }, {
    "url": "pwa-512x512.png",
    "revision": "99a242fe55e0bd9ba3c5e44f65f2eefc"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "99a242fe55e0bd9ba3c5e44f65f2eefc"
  }, {
    "url": "manifest.webmanifest",
    "revision": "b593ec8a6eeddb98f305a4afda88bf74"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
